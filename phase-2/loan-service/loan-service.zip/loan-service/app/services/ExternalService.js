import axios from 'axios';

const USER_SERVICE_URL = process.env.USER_SERVICE_URL || 'http://localhost:8081';
const BOOK_SERVICE_URL = process.env.BOOK_SERVICE_URL || 'http://localhost:8082';

class ExternalService {
  static async validateUser(userId) {
    try {
      const response = await axios.get(`${USER_SERVICE_URL}/api/users/${userId}`);
      return response.data;
    } catch (error) {
      throw new Error('User validation failed');
    }
  }

  static async validateBook(bookId) {
    try {
      const response = await axios.get(`${BOOK_SERVICE_URL}/api/books/${bookId}`);
      return response.data;
    } catch (error) {
      throw new Error('Book validation failed');
    }
  }

  static async updateBookAvailability(bookId, increment = false) {
    try {
      const response = await axios.patch(`${BOOK_SERVICE_URL}/api/books/${bookId}/availability`, {
        available_copies: 1,
        operation: increment ? 'increment' : 'decrement'
      });
      return response.data;
    } catch (error) {
      console.error('Book availability update error:', error.response?.data || error.message);
      throw new Error('Failed to update book availability');
    }
  }

  static async getUserDetails(userId) {
    try {
      const response = await axios.get(`${USER_SERVICE_URL}/api/users/${userId}`);
      return response.data;
    } catch (error) {
      throw new Error('Failed to get user details');
    }
  }

  static async getBookDetails(bookId) {
    try {
      const response = await axios.get(`${BOOK_SERVICE_URL}/api/books/${bookId}`);
      return response.data;
    } catch (error) {
      throw new Error('Failed to get book details');
    }
  }
}

export default ExternalService; 