import Loan from '../models/Loan.js';
import ExternalService from '../services/ExternalService.js';

class LoanController {
  static async issueBook(req, res) {
    try {
      const { user_id, book_id, due_date } = req.body;

      // Convert IDs to strings if they aren't already
      const userId = String(user_id);
      const bookId = String(book_id);

      // Validate user
      await ExternalService.validateUser(userId);

      // Validate book and check availability
      const book = await ExternalService.validateBook(bookId);
      if (!book.available_copies || book.available_copies <= 0) {
        return res.status(400).json({ error: 'Book is not available for loan' });
      }

      // Create loan record
      const loan = new Loan({
        user_id: userId,
        book_id: bookId,
        due_date: new Date(due_date)
      });

      await loan.save();

      try {
        // Update book availability
        await ExternalService.updateBookAvailability(bookId);
        
        res.status(201).json({
          id: loan._id,
          user_id: loan.user_id,
          book_id: loan.book_id,
          issue_date: loan.issue_date,
          due_date: loan.due_date,
          status: loan.status
        });
      } catch (error) {
        // If book availability update fails, delete the loan record
        await Loan.findByIdAndDelete(loan._id);
        throw error;
      }
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  static async returnBook(req, res) {
    try {
      const { loan_id } = req.body;

      const loan = await Loan.findById(loan_id);
      if (!loan) {
        return res.status(404).json({ error: 'Loan not found' });
      }

      if (loan.status === 'RETURNED') {
        return res.status(400).json({ error: 'Book already returned' });
      }

      loan.status = 'RETURNED';
      loan.return_date = new Date();
      await loan.save();

      try {
        await ExternalService.updateBookAvailability(loan.book_id, true);
        
        res.json({
          id: loan._id,
          user_id: loan.user_id,
          book_id: loan.book_id,
          issue_date: loan.issue_date,
          due_date: loan.due_date,
          return_date: loan.return_date,
          status: loan.status
        });
      } catch (error) {
        loan.status = 'ACTIVE';
        loan.return_date = undefined;
        await loan.save();
        throw error;
      }
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  static async getUserLoans(req, res) {
    try {
      const { user_id } = req.params;
      const userId = String(user_id);

      // Validate user
      await ExternalService.validateUser(userId);

      const loans = await Loan.find({ user_id: userId });
      const loansWithDetails = await Promise.all(
        loans.map(async (loan) => {
          const book = await ExternalService.getBookDetails(loan.book_id);
          return {
            id: loan._id,
            book: {
              id: book.id,
              title: book.title,
              author: book.author
            },
            issue_date: loan.issue_date,
            due_date: loan.due_date,
            return_date: loan.status === 'RETURNED' ? loan.return_date : null,
            status: loan.status
          };
        })
      );

      res.json({
        loans: loansWithDetails,
        total: loansWithDetails.length
      });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  static async getLoanDetails(req, res) {
    try {
      const { id } = req.params;

      const loan = await Loan.findById(id);
      if (!loan) {
        return res.status(404).json({ error: 'Loan not found' });
      }

      const [user, book] = await Promise.all([
        ExternalService.getUserDetails(loan.user_id),
        ExternalService.getBookDetails(loan.book_id)
      ]);

      res.json({
        id: loan._id,
        user: {
          id: user._id,
          name: user.name,
          email: user.email
        },
        book: {
          id: book.id,
          title: book.title,
          author: book.author
        },
        issue_date: loan.issue_date,
        due_date: loan.due_date,
        return_date: loan.status === 'RETURNED' ? loan.return_date : null,
        status: loan.status
      });
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }
}

export default LoanController;
